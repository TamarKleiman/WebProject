import React from 'react'
function Title(){

    return(
        <div>
            <h1>My Keyboard</h1>
        </div>
    );
}

export default Title