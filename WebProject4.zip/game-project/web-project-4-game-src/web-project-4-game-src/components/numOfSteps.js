import React from "react";

function NumOfSteps(props){

    return(
        <div>
            <h1>steps  =={'>'} {props.steps} </h1>
        </div>
    )
   
}

export default NumOfSteps
