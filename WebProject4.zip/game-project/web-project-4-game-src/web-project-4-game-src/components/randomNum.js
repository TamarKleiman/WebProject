import React from "react";
// import ReactDOM from "react-dom";

function RandomNum(props){

    return(
        <div>
            <h1>number =={'>'} {props.number}</h1> 
        </div>
    );
   
}
export default RandomNum
