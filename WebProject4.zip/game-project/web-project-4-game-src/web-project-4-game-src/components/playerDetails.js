import React from "react";
// import ReactDOM from "react-dom";

function PlayerDetails(props){

    return(
        <div>
            <h1>player  =={'>'} {props.name}</h1>
        </div>
    )
   
}
export default PlayerDetails