import React from 'react';

export default function Albums(){

    return(
        <div>
            
        </div>
    )
};